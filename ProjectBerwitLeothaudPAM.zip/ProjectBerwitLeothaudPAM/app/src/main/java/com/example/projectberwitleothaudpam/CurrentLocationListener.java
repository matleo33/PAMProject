package com.example.projectberwitleothaudpam;

import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import static android.content.ContentValues.TAG;

/**
 * Created by yonnel on 29/12/2019.
 */

public class CurrentLocationListener implements android.location.LocationListener {
    @Override
    public void onLocationChanged(Location loc) {
        System.out.println(loc.getLatitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
