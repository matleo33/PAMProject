package com.example.projectberwitleothaudpam;

import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class InvitationRequestMaps extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private String number;
    private TextView informations;
    private String latitude;
    private String longitude;

    public String getContactName(final String phoneNumber, Context context)
    {
        Uri uri=Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,Uri.encode(phoneNumber));

        String[] projection = new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME};

        String contactName="";
        Cursor cursor=context.getContentResolver().query(uri,projection,null,null,null);

        if (cursor != null) {
            if(cursor.moveToFirst()) {
                contactName=cursor.getString(0);
            }
            cursor.close();
        } else {
            contactName = phoneNumber;
        }

        return contactName;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invitation_request_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //On parse l'url pour récupérer les données
        Uri url = getIntent().getData();
        String strUrl = url.toString();
        String data[] = strUrl.split("\\?");
        data = data[1].split("&");
        String phoneNumber [] = data[0].split("=");
        number = phoneNumber[1];

        String longitudeCoord [] = data[2].split("=");
        longitude = longitudeCoord[1];

        String latitudeCoord [] = data[1].split("=");
        latitude = latitudeCoord[1];

        informations = findViewById(R.id.informations);
        String tmp = getContactName(number,getApplicationContext());
        informations.setText("This number/person is trying to get an appointment with you : \n"
                + tmp
                + "\nThey want to have it there : \nLat : " + latitude + " Lon : " + longitude);
    }

    public void confirmation(View view) {
        String messageToSend = "The appointment has been confirmed";
        SmsManager.getDefault().sendTextMessage(number, null, messageToSend, null,null);
    }

    public void refus(View view) {
        String messageToSend = "The appointment has been declined";
        SmsManager.getDefault().sendTextMessage(number, null, messageToSend, null,null);
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng appointment = new LatLng(Integer.parseInt(latitude), Integer.parseInt(longitude));
        mMap.addMarker(new MarkerOptions().position(appointment).title("Appointment"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(appointment));
    }
}
