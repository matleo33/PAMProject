package com.example.projectberwitleothaudpam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Toast;

public class NewDate extends AppCompatActivity {

    CurrentLocationListener locationListener;
    LocationManager locationManager;
    TelephonyManager tm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_date);

        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        locationListener= new CurrentLocationListener();

        tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
    }

    public void createAppointment(View view) {
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 20000, 0, locationListener);
            Location loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            String telNumber = tm.getLine1Number();

            Intent sendAppointment = new Intent(Intent.ACTION_VIEW);
            sendAppointment.setData(Uri.parse("sms:"));
            sendAppointment.putExtra("sms_body", "http://yourdomain.com/appointment?phone=" + telNumber + "&latitude=" + loc.getLatitude() + "&longitude=" + loc.getLongitude());
            startActivity(sendAppointment);
        } catch (SecurityException e) {
            Toast.makeText(this, "Localisation non autorisée : Suite impossible",
                    Toast.LENGTH_LONG).show();
        }
    }
}
